package Controllers;

import Interfaces.Employee;

public interface CleaningController extends Employee {
    int cleanClassrooms(int amount);

}
