package Controllers;

import Interfaces.Employee;

public interface ElectricianController extends Employee {

    void checkBulbs();
}
