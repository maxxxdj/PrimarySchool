package Staff.OtherStaff;

import Interfaces.Employee;

public interface ElectricianController extends Employee {

    void checkBulbs();
}
